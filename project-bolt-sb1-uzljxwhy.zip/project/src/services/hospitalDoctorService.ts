import { 
  doctors, 
  hospitals, 
  specialties, 
  hospitalDoctorAssignments,
  type Doctor,
  type Hospital,
  type Specialty,
  type HospitalDoctorAssignment
} from '../data/hospitalDoctorData';

export class HospitalDoctorService {
  // Get all hospitals
  static getAllHospitals(): Hospital[] {
    return hospitals;
  }

  // Get hospital by ID
  static getHospitalById(hospitalId: string): Hospital | undefined {
    return hospitals.find(hospital => hospital.id === hospitalId);
  }

  // Get all doctors
  static getAllDoctors(): Doctor[] {
    return doctors;
  }

  // Get doctor by ID
  static getDoctorById(doctorId: string): Doctor | undefined {
    return doctors.find(doctor => doctor.id === doctorId);
  }

  // Get all specialties
  static getAllSpecialties(): Specialty[] {
    return specialties;
  }

  // Get specialty by ID
  static getSpecialtyById(specialtyId: string): Specialty | undefined {
    return specialties.find(specialty => specialty.id === specialtyId);
  }

  // Get doctors assigned to a specific hospital
  static getDoctorsByHospital(hospitalId: string): Array<Doctor & { assignment: HospitalDoctorAssignment }> {
    const assignments = hospitalDoctorAssignments.filter(
      assignment => assignment.hospitalId === hospitalId
    );

    return assignments.map(assignment => {
      const doctor = doctors.find(doc => doc.id === assignment.doctorId);
      if (!doctor) throw new Error(`Doctor not found: ${assignment.doctorId}`);
      
      return {
        ...doctor,
        assignment
      };
    });
  }

  // Get doctors by hospital and specialty
  static getDoctorsByHospitalAndSpecialty(
    hospitalId: string, 
    specialtyId: string
  ): Array<Doctor & { assignment: HospitalDoctorAssignment }> {
    const assignments = hospitalDoctorAssignments.filter(
      assignment => 
        assignment.hospitalId === hospitalId && 
        assignment.specialtyId === specialtyId
    );

    return assignments.map(assignment => {
      const doctor = doctors.find(doc => doc.id === assignment.doctorId);
      if (!doctor) throw new Error(`Doctor not found: ${assignment.doctorId}`);
      
      return {
        ...doctor,
        assignment
      };
    });
  }

  // Get specialties available at a specific hospital
  static getSpecialtiesByHospital(hospitalId: string): Array<Specialty & { doctorCount: number }> {
    const assignments = hospitalDoctorAssignments.filter(
      assignment => assignment.hospitalId === hospitalId
    );

    const specialtyGroups = assignments.reduce((acc, assignment) => {
      if (!acc[assignment.specialtyId]) {
        acc[assignment.specialtyId] = [];
      }
      acc[assignment.specialtyId].push(assignment);
      return acc;
    }, {} as Record<string, HospitalDoctorAssignment[]>);

    return Object.keys(specialtyGroups).map(specialtyId => {
      const specialty = specialties.find(spec => spec.id === specialtyId);
      if (!specialty) throw new Error(`Specialty not found: ${specialtyId}`);
      
      return {
        ...specialty,
        doctorCount: specialtyGroups[specialtyId].length
      };
    });
  }

  // Get hospitals where a specific doctor practices
  static getHospitalsByDoctor(doctorId: string): Array<Hospital & { assignment: HospitalDoctorAssignment }> {
    const assignments = hospitalDoctorAssignments.filter(
      assignment => assignment.doctorId === doctorId
    );

    return assignments.map(assignment => {
      const hospital = hospitals.find(hosp => hosp.id === assignment.hospitalId);
      if (!hospital) throw new Error(`Hospital not found: ${assignment.hospitalId}`);
      
      return {
        ...hospital,
        assignment
      };
    });
  }

  // Add new hospital-doctor assignment
  static addHospitalDoctorAssignment(assignment: HospitalDoctorAssignment): void {
    // Check if assignment already exists
    const existingAssignment = hospitalDoctorAssignments.find(
      existing => 
        existing.hospitalId === assignment.hospitalId &&
        existing.doctorId === assignment.doctorId &&
        existing.specialtyId === assignment.specialtyId
    );

    if (existingAssignment) {
      throw new Error('Assignment already exists');
    }

    hospitalDoctorAssignments.push(assignment);
  }

  // Remove hospital-doctor assignment
  static removeHospitalDoctorAssignment(
    hospitalId: string, 
    doctorId: string, 
    specialtyId: string
  ): boolean {
    const index = hospitalDoctorAssignments.findIndex(
      assignment => 
        assignment.hospitalId === hospitalId &&
        assignment.doctorId === doctorId &&
        assignment.specialtyId === specialtyId
    );

    if (index === -1) {
      return false;
    }

    hospitalDoctorAssignments.splice(index, 1);
    return true;
  }

  // Update hospital-doctor assignment
  static updateHospitalDoctorAssignment(
    hospitalId: string,
    doctorId: string,
    specialtyId: string,
    updates: Partial<HospitalDoctorAssignment>
  ): boolean {
    const index = hospitalDoctorAssignments.findIndex(
      assignment => 
        assignment.hospitalId === hospitalId &&
        assignment.doctorId === doctorId &&
        assignment.specialtyId === specialtyId
    );

    if (index === -1) {
      return false;
    }

    hospitalDoctorAssignments[index] = {
      ...hospitalDoctorAssignments[index],
      ...updates
    };

    return true;
  }

  // Search doctors by name, specialty, or hospital
  static searchDoctors(query: string): Array<Doctor & { hospitals: Hospital[] }> {
    const lowercaseQuery = query.toLowerCase();
    
    const matchingDoctors = doctors.filter(doctor => 
      doctor.name.toLowerCase().includes(lowercaseQuery) ||
      doctor.specialty.toLowerCase().includes(lowercaseQuery)
    );

    return matchingDoctors.map(doctor => ({
      ...doctor,
      hospitals: this.getHospitalsByDoctor(doctor.id)
    }));
  }

  // Search hospitals by name or location
  static searchHospitals(query: string): Hospital[] {
    const lowercaseQuery = query.toLowerCase();
    
    return hospitals.filter(hospital => 
      hospital.name.toLowerCase().includes(lowercaseQuery) ||
      hospital.location.toLowerCase().includes(lowercaseQuery) ||
      hospital.address.toLowerCase().includes(lowercaseQuery)
    );
  }

  // Get statistics
  static getStatistics() {
    return {
      totalHospitals: hospitals.length,
      totalDoctors: doctors.length,
      totalSpecialties: specialties.length,
      totalAssignments: hospitalDoctorAssignments.length,
      averageRating: {
        hospitals: hospitals.reduce((sum, h) => sum + h.rating, 0) / hospitals.length,
        doctors: doctors.reduce((sum, d) => sum + d.rating, 0) / doctors.length
      }
    };
  }
}