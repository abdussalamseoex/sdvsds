// Hospital-Doctor relationship data structure
export interface Doctor {
  id: string;
  name: string;
  image: string;
  specialty: string;
  specialtyId: string;
  rating: number;
  reviews: number;
  experience: string;
  verified: boolean;
  phone: string;
  email: string;
  consultationFee: {
    new_patient: number;
    follow_up: number;
    online: number;
  };
  schedule: {
    day: string;
    time: string;
  }[];
  appointmentProcess: string;
}

export interface Hospital {
  id: string;
  name: string;
  image: string;
  rating: number;
  reviews: number;
  location: string;
  address: string;
  phone: string;
  emergency_phone: string;
  email: string;
  website: string;
  beds: number;
  established: string;
  accredited: boolean;
  emergency: boolean;
  description: string;
  facilities: string[];
  services: string[];
  operating_hours: {
    opd: string;
    emergency: string;
    pharmacy: string;
    lab: string;
  };
  gallery: string[];
}

export interface Specialty {
  id: string;
  name: string;
  icon: string;
  description: string;
}

export interface HospitalDoctorAssignment {
  hospitalId: string;
  doctorId: string;
  specialtyId: string;
  schedule: {
    day: string;
    time: string;
  }[];
  appointmentProcess: string;
  chamberLocation?: string;
}

// Sample data
export const specialties: Specialty[] = [
  { id: 'cardiology', name: 'Cardiology', icon: 'Heart', description: 'Heart and cardiovascular system care' },
  { id: 'neurology', name: 'Neurology', icon: 'Brain', description: 'Brain and nervous system treatment' },
  { id: 'ophthalmology', name: 'Ophthalmology', icon: 'Eye', description: 'Eye and vision care specialists' },
  { id: 'orthopedics', name: 'Orthopedics', icon: 'Bone', description: 'Bone, joint, and muscle care' },
  { id: 'pediatrics', name: 'Pediatrics', icon: 'Baby', description: 'Children\'s health and development' },
  { id: 'emergency', name: 'Emergency Medicine', icon: 'Activity', description: '24/7 urgent medical attention' },
  { id: 'general', name: 'General Medicine', icon: 'Stethoscope', description: 'Primary healthcare services' },
  { id: 'surgery', name: 'Surgery', icon: 'Scissors', description: 'Surgical procedures and operations' }
];

export const doctors: Doctor[] = [
  {
    id: 'prof-dr-kamol-krishna-karmakar',
    name: 'Prof. Dr. Kamol Krishna Karmakar',
    image: 'https://images.pexels.com/photos/5327921/pexels-photo-5327921.jpeg?auto=compress&cs=tinysrgb&w=400',
    specialty: 'Cardiologist & Cardiac Surgeon',
    specialtyId: 'cardiology',
    rating: 4.9,
    reviews: 156,
    experience: '25 years',
    verified: true,
    phone: '+880-1711-123456',
    email: 'dr.kamol@example.com',
    consultationFee: {
      new_patient: 2000,
      follow_up: 1500,
      online: 1200
    },
    schedule: [],
    appointmentProcess: ''
  },
  {
    id: 'dr-sarah-johnson',
    name: 'Dr. Sarah Johnson',
    image: 'https://images.pexels.com/photos/5327921/pexels-photo-5327921.jpeg?auto=compress&cs=tinysrgb&w=400',
    specialty: 'Cardiologist',
    specialtyId: 'cardiology',
    rating: 4.9,
    reviews: 128,
    experience: '15 years',
    verified: true,
    phone: '+1 (555) 123-4567',
    email: 'dr.sarah@example.com',
    consultationFee: {
      new_patient: 1800,
      follow_up: 1200,
      online: 1000
    },
    schedule: [],
    appointmentProcess: ''
  },
  {
    id: 'dr-michael-chen',
    name: 'Dr. Michael Chen',
    image: 'https://images.pexels.com/photos/6749778/pexels-photo-6749778.jpeg?auto=compress&cs=tinysrgb&w=400',
    specialty: 'Neurologist',
    specialtyId: 'neurology',
    rating: 4.8,
    reviews: 95,
    experience: '12 years',
    verified: true,
    phone: '+1 (555) 987-6543',
    email: 'dr.michael@example.com',
    consultationFee: {
      new_patient: 2200,
      follow_up: 1600,
      online: 1300
    },
    schedule: [],
    appointmentProcess: ''
  },
  {
    id: 'dr-emily-rodriguez',
    name: 'Dr. Emily Rodriguez',
    image: 'https://images.pexels.com/photos/5452293/pexels-photo-5452293.jpeg?auto=compress&cs=tinysrgb&w=400',
    specialty: 'Pediatrician',
    specialtyId: 'pediatrics',
    rating: 5.0,
    reviews: 156,
    experience: '10 years',
    verified: true,
    phone: '+1 (555) 456-7890',
    email: 'dr.emily@example.com',
    consultationFee: {
      new_patient: 1500,
      follow_up: 1000,
      online: 800
    },
    schedule: [],
    appointmentProcess: ''
  },
  {
    id: 'dr-ahmed-hassan',
    name: 'Dr. Ahmed Hassan',
    image: 'https://images.pexels.com/photos/6749778/pexels-photo-6749778.jpeg?auto=compress&cs=tinysrgb&w=400',
    specialty: 'Orthopedic Surgeon',
    specialtyId: 'orthopedics',
    rating: 4.7,
    reviews: 89,
    experience: '18 years',
    verified: true,
    phone: '+880-1711-987654',
    email: 'dr.ahmed@example.com',
    consultationFee: {
      new_patient: 2500,
      follow_up: 1800,
      online: 1500
    },
    schedule: [],
    appointmentProcess: ''
  },
  {
    id: 'dr-fatima-begum',
    name: 'Dr. Fatima Begum',
    image: 'https://images.pexels.com/photos/5452293/pexels-photo-5452293.jpeg?auto=compress&cs=tinysrgb&w=400',
    specialty: 'Ophthalmologist',
    specialtyId: 'ophthalmology',
    rating: 4.8,
    reviews: 112,
    experience: '14 years',
    verified: true,
    phone: '+880-1711-456789',
    email: 'dr.fatima@example.com',
    consultationFee: {
      new_patient: 1800,
      follow_up: 1200,
      online: 1000
    },
    schedule: [],
    appointmentProcess: ''
  }
];

export const hospitals: Hospital[] = [
  {
    id: 'dhaka-central-international-medical-college-hospital',
    name: 'Dhaka Central International Medical College Hospital',
    image: 'https://images.pexels.com/photos/263402/pexels-photo-263402.jpeg?auto=compress&cs=tinysrgb&w=1200',
    rating: 4.8,
    reviews: 342,
    location: 'Dhanmondi, Dhaka, Bangladesh',
    address: '2/1 Humayun Road, Mohammadpur, Dhaka 1207',
    phone: '+880-2-9661991',
    emergency_phone: '+880-2-9661992',
    email: 'info@dcimch.edu.bd',
    website: 'www.dcimch.edu.bd',
    beds: 450,
    established: '2005',
    accredited: true,
    emergency: true,
    description: 'Dhaka Central International Medical College Hospital is a premier healthcare institution providing comprehensive medical services with state-of-the-art facilities and experienced medical professionals.',
    facilities: ['ICU & CCU', 'Operation Theater', 'Emergency Department', 'Diagnostic Center', 'Pharmacy', 'Blood Bank', 'Ambulance Service', 'Cafeteria'],
    services: ['24/7 Emergency Care', 'Outpatient Services', 'Inpatient Care', 'Surgical Procedures', 'Diagnostic Imaging', 'Laboratory Services', 'Rehabilitation', 'Health Checkups'],
    operating_hours: {
      opd: 'Monday - Saturday: 8:00 AM - 8:00 PM, Sunday: 10:00 AM - 6:00 PM',
      emergency: '24/7',
      pharmacy: 'Monday - Sunday: 8:00 AM - 10:00 PM',
      lab: 'Monday - Sunday: 7:00 AM - 9:00 PM'
    },
    gallery: [
      'https://images.pexels.com/photos/668300/pexels-photo-668300.jpeg?auto=compress&cs=tinysrgb&w=400',
      'https://images.pexels.com/photos/1692693/pexels-photo-1692693.jpeg?auto=compress&cs=tinysrgb&w=400',
      'https://images.pexels.com/photos/4021775/pexels-photo-4021775.jpeg?auto=compress&cs=tinysrgb&w=400',
      'https://images.pexels.com/photos/4386467/pexels-photo-4386467.jpeg?auto=compress&cs=tinysrgb&w=400'
    ]
  },
  {
    id: 'metropolitan-general-hospital',
    name: 'Metropolitan General Hospital',
    image: 'https://images.pexels.com/photos/263402/pexels-photo-263402.jpeg?auto=compress&cs=tinysrgb&w=600',
    rating: 4.8,
    reviews: 342,
    location: 'New York, NY',
    address: '123 Medical Center Drive, New York, NY 10001',
    phone: '+1 (555) 123-4567',
    emergency_phone: '+1 (555) 123-4568',
    email: 'info@metgeneral.com',
    website: 'www.metgeneral.com',
    beds: 450,
    established: '1985',
    accredited: true,
    emergency: true,
    description: 'Metropolitan General Hospital is a leading healthcare facility providing comprehensive medical services with cutting-edge technology and expert medical staff.',
    facilities: ['ICU & CCU', 'Operation Theater', 'Emergency Department', 'Diagnostic Center', 'Pharmacy', 'Blood Bank', 'Ambulance Service', 'Cafeteria'],
    services: ['24/7 Emergency Care', 'Outpatient Services', 'Inpatient Care', 'Surgical Procedures', 'Diagnostic Imaging', 'Laboratory Services', 'Rehabilitation', 'Health Checkups'],
    operating_hours: {
      opd: 'Monday - Friday: 8:00 AM - 8:00 PM, Saturday: 9:00 AM - 5:00 PM',
      emergency: '24/7',
      pharmacy: 'Monday - Sunday: 8:00 AM - 10:00 PM',
      lab: 'Monday - Sunday: 7:00 AM - 9:00 PM'
    },
    gallery: [
      'https://images.pexels.com/photos/668300/pexels-photo-668300.jpeg?auto=compress&cs=tinysrgb&w=400',
      'https://images.pexels.com/photos/1692693/pexels-photo-1692693.jpeg?auto=compress&cs=tinysrgb&w=400'
    ]
  },
  {
    id: 'st-marys-medical-center',
    name: 'St. Mary\'s Medical Center',
    image: 'https://images.pexels.com/photos/668300/pexels-photo-668300.jpeg?auto=compress&cs=tinysrgb&w=600',
    rating: 4.9,
    reviews: 278,
    location: 'Los Angeles, CA',
    address: '456 Healthcare Boulevard, Los Angeles, CA 90210',
    phone: '+1 (555) 987-6543',
    emergency_phone: '+1 (555) 987-6544',
    email: 'contact@stmarysmedical.com',
    website: 'www.stmarysmedical.com',
    beds: 320,
    established: '1962',
    accredited: true,
    emergency: true,
    description: 'St. Mary\'s Medical Center has been serving the community for over 60 years with compassionate care and advanced medical treatments.',
    facilities: ['ICU & CCU', 'Operation Theater', 'Emergency Department', 'Diagnostic Center', 'Pharmacy', 'Blood Bank', 'Ambulance Service', 'Cafeteria'],
    services: ['24/7 Emergency Care', 'Outpatient Services', 'Inpatient Care', 'Surgical Procedures', 'Diagnostic Imaging', 'Laboratory Services', 'Rehabilitation', 'Health Checkups'],
    operating_hours: {
      opd: 'Monday - Saturday: 8:00 AM - 8:00 PM, Sunday: 10:00 AM - 6:00 PM',
      emergency: '24/7',
      pharmacy: 'Monday - Sunday: 8:00 AM - 10:00 PM',
      lab: 'Monday - Sunday: 7:00 AM - 9:00 PM'
    },
    gallery: [
      'https://images.pexels.com/photos/668300/pexels-photo-668300.jpeg?auto=compress&cs=tinysrgb&w=400',
      'https://images.pexels.com/photos/1692693/pexels-photo-1692693.jpeg?auto=compress&cs=tinysrgb&w=400'
    ]
  }
];

// Hospital-Doctor assignments with schedules
export const hospitalDoctorAssignments: HospitalDoctorAssignment[] = [
  // Dhaka Central International Medical College Hospital
  {
    hospitalId: 'dhaka-central-international-medical-college-hospital',
    doctorId: 'prof-dr-kamol-krishna-karmakar',
    specialtyId: 'cardiology',
    schedule: [
      { day: 'Monday', time: '9:00 AM - 1:00 PM' },
      { day: 'Wednesday', time: '9:00 AM - 1:00 PM' },
      { day: 'Friday', time: '9:00 AM - 1:00 PM' }
    ],
    appointmentProcess: 'Call hospital reception at +880-2-9661991 or visit in person. Online booking available through hospital website.',
    chamberLocation: 'Cardiology Department, 3rd Floor'
  },
  {
    hospitalId: 'dhaka-central-international-medical-college-hospital',
    doctorId: 'dr-ahmed-hassan',
    specialtyId: 'orthopedics',
    schedule: [
      { day: 'Tuesday', time: '2:00 PM - 6:00 PM' },
      { day: 'Thursday', time: '2:00 PM - 6:00 PM' },
      { day: 'Saturday', time: '10:00 AM - 2:00 PM' }
    ],
    appointmentProcess: 'Call hospital reception at +880-2-9661991 or visit in person. Online booking available through hospital website.',
    chamberLocation: 'Orthopedics Department, 2nd Floor'
  },
  {
    hospitalId: 'dhaka-central-international-medical-college-hospital',
    doctorId: 'dr-fatima-begum',
    specialtyId: 'ophthalmology',
    schedule: [
      { day: 'Monday', time: '10:00 AM - 2:00 PM' },
      { day: 'Wednesday', time: '10:00 AM - 2:00 PM' },
      { day: 'Friday', time: '10:00 AM - 2:00 PM' }
    ],
    appointmentProcess: 'Call hospital reception at +880-2-9661991 or visit in person. Online booking available through hospital website.',
    chamberLocation: 'Eye Department, 1st Floor'
  },

  // Metropolitan General Hospital
  {
    hospitalId: 'metropolitan-general-hospital',
    doctorId: 'dr-sarah-johnson',
    specialtyId: 'cardiology',
    schedule: [
      { day: 'Monday', time: '9:00 AM - 1:00 PM' },
      { day: 'Wednesday', time: '9:00 AM - 1:00 PM' },
      { day: 'Friday', time: '9:00 AM - 1:00 PM' }
    ],
    appointmentProcess: 'Call hospital reception at +1 (555) 123-4567 or use online booking system.',
    chamberLocation: 'Cardiology Wing, 4th Floor'
  },
  {
    hospitalId: 'metropolitan-general-hospital',
    doctorId: 'dr-michael-chen',
    specialtyId: 'neurology',
    schedule: [
      { day: 'Tuesday', time: '5:00 PM - 9:00 PM' },
      { day: 'Thursday', time: '5:00 PM - 9:00 PM' },
      { day: 'Saturday', time: '9:00 AM - 1:00 PM' }
    ],
    appointmentProcess: 'Call hospital reception at +1 (555) 123-4567 or use online booking system.',
    chamberLocation: 'Neurology Department, 5th Floor'
  },

  // St. Mary's Medical Center
  {
    hospitalId: 'st-marys-medical-center',
    doctorId: 'dr-emily-rodriguez',
    specialtyId: 'pediatrics',
    schedule: [
      { day: 'Monday', time: '8:00 AM - 4:00 PM' },
      { day: 'Tuesday', time: '8:00 AM - 4:00 PM' },
      { day: 'Wednesday', time: '8:00 AM - 4:00 PM' },
      { day: 'Thursday', time: '8:00 AM - 4:00 PM' },
      { day: 'Friday', time: '8:00 AM - 4:00 PM' },
      { day: 'Saturday', time: '8:00 AM - 4:00 PM' }
    ],
    appointmentProcess: 'Call hospital hotline at +1 (555) 987-6543 or use St. Mary\'s mobile app for appointment booking.',
    chamberLocation: 'Pediatrics Ward, 2nd Floor'
  },
  {
    hospitalId: 'st-marys-medical-center',
    doctorId: 'dr-michael-chen',
    specialtyId: 'neurology',
    schedule: [
      { day: 'Monday', time: '10:00 AM - 2:00 PM' },
      { day: 'Friday', time: '10:00 AM - 2:00 PM' }
    ],
    appointmentProcess: 'Call hospital hotline at +1 (555) 987-6543 or use St. Mary\'s mobile app for appointment booking.',
    chamberLocation: 'Neurology Department, 3rd Floor'
  }
];