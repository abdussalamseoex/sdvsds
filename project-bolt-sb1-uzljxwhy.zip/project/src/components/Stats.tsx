import React from 'react';
import { Users, Stethoscope, Building2, Award } from 'lucide-react';

const Stats = () => {
  const stats = [
    {
      icon: Users,
      number: '50,000+',
      label: 'Happy Patients',
      color: 'bg-blue-100 text-blue-600'
    },
    {
      icon: Stethoscope,
      number: '2,500+',
      label: 'Expert Doctors',
      color: 'bg-green-100 text-green-600'
    },
    {
      icon: Building2,
      number: '150+',
      label: 'Partner Hospitals',
      color: 'bg-purple-100 text-purple-600'
    },
    {
      icon: Award,
      number: '25+',
      label: 'Years Experience',
      color: 'bg-orange-100 text-orange-600'
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className={`w-16 h-16 ${stat.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                <stat.icon className="h-8 w-8" />
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-2">{stat.number}</div>
              <div className="text-gray-600 font-medium">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Stats;