import React from 'react';
import { Star, Quote } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      name: 'Jennifer Martinez',
      image: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=200',
      rating: 5,
      text: 'HealthHub helped me find the perfect cardiologist and a top-rated hospital for my surgery. The platform made everything so easy and stress-free.',
      treatment: 'Cardiac Surgery at Metropolitan General'
    },
    {
      name: 'Robert Thompson',
      image: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=200',
      rating: 5,
      text: 'Amazing platform! I found both a pediatrician and the best children\'s hospital in my area. The reviews and ratings were incredibly helpful.',
      treatment: 'Pediatric Care at St. Mary\'s Medical'
    },
    {
      name: 'Lisa Chen',
      image: 'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg?auto=compress&cs=tinysrgb&w=200',
      rating: 5,
      text: 'The convenience of finding both doctors and hospitals in one place is incredible. I can compare facilities and make informed healthcare decisions.',
      treatment: 'General Consultation & Diagnostics'
    }
  ];

  return (
    <section className="py-20 bg-blue-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            What Our Patients Say
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Read testimonials from thousands of satisfied patients who found their ideal healthcare providers and facilities
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white rounded-xl shadow-md p-6 relative">
              <Quote className="absolute top-4 right-4 h-8 w-8 text-blue-200" />
              
              <div className="flex items-center mb-4">
                <img
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover mr-4"
                />
                <div>
                  <h4 className="font-semibold text-gray-900">{testimonial.name}</h4>
                  <div className="flex items-center">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                    ))}
                  </div>
                </div>
              </div>

              <p className="text-gray-600 mb-4 leading-relaxed">
                "{testimonial.text}"
              </p>

              <div className="text-sm text-blue-600 font-medium">
                {testimonial.treatment}
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <button className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium">
            Read More Reviews
          </button>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;