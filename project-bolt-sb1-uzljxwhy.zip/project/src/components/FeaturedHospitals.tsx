import React from 'react';
import { Link } from 'react-router-dom';
import { Star, MapPin, Phone, Bed, Award, Clock, CheckCircle, Globe, Mail } from 'lucide-react';
import { HospitalDoctorService } from '../services/hospitalDoctorService';

const FeaturedHospitals = () => {
  // Get hospitals from the service
  const hospitals = HospitalDoctorService.getAllHospitals().slice(0, 3); // Show first 3 hospitals

  return (
    <section id="hospitals" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Top-Rated Hospitals
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover leading healthcare facilities with complete contact information and appointment procedures
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {hospitals.map((hospital, index) => {
            // Get doctor count for this hospital
            const doctorCount = HospitalDoctorService.getDoctorsByHospital(hospital.id).length;
            // Get specialties for this hospital
            const specialties = HospitalDoctorService.getSpecialtiesByHospital(hospital.id);

            return (
              <div key={index} className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow overflow-hidden">
                <div className="relative">
                  <img
                    src={hospital.image}
                    alt={hospital.name}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute top-4 left-4 flex space-x-2">
                    {hospital.accredited && (
                      <div className="bg-green-500 text-white px-2 py-1 rounded-full flex items-center space-x-1 text-xs">
                        <CheckCircle className="h-3 w-3" />
                        <span>Accredited</span>
                      </div>
                    )}
                    {hospital.emergency && (
                      <div className="bg-red-500 text-white px-2 py-1 rounded-full flex items-center space-x-1 text-xs">
                        <Clock className="h-3 w-3" />
                        <span>24/7 ER</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="p-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    {hospital.name}
                  </h3>

                  <div className="flex items-center space-x-4 mb-4">
                    <div className="flex items-center space-x-1">
                      <Star className="h-4 w-4 text-yellow-400 fill-current" />
                      <span className="font-medium">{hospital.rating}</span>
                      <span className="text-gray-600 text-sm">({hospital.reviews})</span>
                    </div>
                    <div className="flex items-center space-x-1 text-gray-600 text-sm">
                      <MapPin className="h-4 w-4" />
                      <span>{hospital.location}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                    <div className="flex items-center space-x-2">
                      <Bed className="h-4 w-4 text-blue-600" />
                      <span>{hospital.beds} Beds</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Award className="h-4 w-4 text-green-600" />
                      <span>Est. {hospital.established}</span>
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="text-sm text-gray-600 mb-2">Contact Information:</div>
                    <div className="space-y-1 text-sm">
                      <div className="flex items-center space-x-2 text-gray-700">
                        <Phone className="h-3 w-3" />
                        <span>{hospital.phone}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-gray-700">
                        <Mail className="h-3 w-3" />
                        <span>{hospital.email}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-gray-700">
                        <Globe className="h-3 w-3" />
                        <span>{hospital.website}</span>
                      </div>
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="text-sm text-gray-600 mb-2">
                      Available Specialties ({specialties.length}):
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {specialties.slice(0, 3).map((specialty, idx) => (
                        <span
                          key={idx}
                          className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full"
                        >
                          {specialty.name}
                        </span>
                      ))}
                      {specialties.length > 3 && (
                        <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full">
                          +{specialties.length - 3} more
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="mb-4 text-sm">
                    <div className="text-gray-600">Doctors Available:</div>
                    <div className="font-medium text-blue-600">{doctorCount} doctors</div>
                  </div>

                  <div className="border-t pt-4">
                    <div className="grid grid-cols-2 gap-3">
                      <a
                        href={`tel:${hospital.phone}`}
                        className="flex items-center justify-center space-x-1 px-4 py-2 border border-blue-600 text-blue-600 rounded-lg hover:bg-blue-50 transition-colors"
                      >
                        <Phone className="h-4 w-4" />
                        <span>Call Now</span>
                      </a>
                      <Link
                        to={`/hospital/${hospital.id}`}
                        className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-center"
                      >
                        View Details
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="text-center mt-12">
          <button className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium">
            Browse All Hospitals
          </button>
        </div>
      </div>
    </section>
  );
};

export default FeaturedHospitals;