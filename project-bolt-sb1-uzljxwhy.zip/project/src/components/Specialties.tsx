import React from 'react';
import { Heart, Brain, Eye, Bone, Baby, Stethoscope, Activity, Pill } from 'lucide-react';

const Specialties = () => {
  const specialties = [
    {
      icon: Heart,
      name: 'Cardiology',
      description: 'Heart and cardiovascular system care',
      count: '250+ Doctors',
      color: 'bg-red-100 text-red-600'
    },
    {
      icon: Brain,
      name: 'Neurology',
      description: 'Brain and nervous system treatment',
      count: '180+ Doctors',
      color: 'bg-purple-100 text-purple-600'
    },
    {
      icon: Eye,
      name: 'Ophthalmology',
      description: 'Eye and vision care specialists',
      count: '120+ Doctors',
      color: 'bg-blue-100 text-blue-600'
    },
    {
      icon: Bone,
      name: 'Orthopedics',
      description: 'Bone, joint, and muscle care',
      count: '200+ Doctors',
      color: 'bg-green-100 text-green-600'
    },
    {
      icon: Baby,
      name: 'Pediatrics',
      description: 'Children\'s health and development',
      count: '150+ Doctors',
      color: 'bg-pink-100 text-pink-600'
    },
    {
      icon: Stethoscope,
      name: 'General Medicine',
      description: 'Primary healthcare services',
      count: '300+ Doctors',
      color: 'bg-indigo-100 text-indigo-600'
    },
    {
      icon: Activity,
      name: 'Emergency Care',
      description: '24/7 urgent medical attention',
      count: '100+ Doctors',
      color: 'bg-orange-100 text-orange-600'
    },
    {
      icon: Pill,
      name: 'Pharmacy',
      description: 'Medication and prescription services',
      count: '80+ Pharmacists',
      color: 'bg-teal-100 text-teal-600'
    }
  ];

  return (
    <section id="specialties" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Medical Specialties
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprehensive healthcare services across all medical specialties with experienced professionals
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {specialties.map((specialty, index) => (
            <div
              key={index}
              className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow cursor-pointer group"
            >
              <div className={`w-14 h-14 ${specialty.color} rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                <specialty.icon className="h-7 w-7" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {specialty.name}
              </h3>
              <p className="text-gray-600 mb-3">
                {specialty.description}
              </p>
              <div className="text-sm font-medium text-blue-600">
                {specialty.count}
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <button className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium">
            View All Specialties
          </button>
        </div>
      </div>
    </section>
  );
};

export default Specialties;