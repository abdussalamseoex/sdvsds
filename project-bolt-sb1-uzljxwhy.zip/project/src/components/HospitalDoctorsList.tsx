import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Star, Phone, Clock, MapPin, CheckCircle, Calendar,
  Heart, Brain, Eye, Bone, Baby, Activity, Stethoscope, Scissors
} from 'lucide-react';
import { HospitalDoctorService } from '../services/hospitalDoctorService';
import type { Doctor, HospitalDoctorAssignment } from '../data/hospitalDoctorData';

interface HospitalDoctorsListProps {
  hospitalId: string;
}

const iconMap = {
  Heart,
  Brain,
  Eye,
  Bone,
  Baby,
  Activity,
  Stethoscope,
  Scissors
};

const HospitalDoctorsList: React.FC<HospitalDoctorsListProps> = ({ hospitalId }) => {
  const [selectedSpecialty, setSelectedSpecialty] = useState<string>('all');
  
  // Get hospital data
  const hospital = HospitalDoctorService.getHospitalById(hospitalId);
  
  // Get specialties available at this hospital
  const availableSpecialties = HospitalDoctorService.getSpecialtiesByHospital(hospitalId);
  
  // Get doctors based on selected specialty
  const doctors = selectedSpecialty === 'all' 
    ? HospitalDoctorService.getDoctorsByHospital(hospitalId)
    : HospitalDoctorService.getDoctorsByHospitalAndSpecialty(hospitalId, selectedSpecialty);

  if (!hospital) {
    return <div>Hospital not found</div>;
  }

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-900">
          Our Doctors at {hospital.name}
        </h2>
        <div className="text-sm text-gray-600">
          {doctors.length} doctor{doctors.length !== 1 ? 's' : ''} available
        </div>
      </div>

      {/* Specialty Filter */}
      <div className="mb-6">
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setSelectedSpecialty('all')}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              selectedSpecialty === 'all'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            All Specialties ({HospitalDoctorService.getDoctorsByHospital(hospitalId).length})
          </button>
          {availableSpecialties.map((specialty) => {
            const IconComponent = iconMap[specialty.icon as keyof typeof iconMap] || Stethoscope;
            return (
              <button
                key={specialty.id}
                onClick={() => setSelectedSpecialty(specialty.id)}
                className={`px-4 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2 ${
                  selectedSpecialty === specialty.id
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <IconComponent className="h-4 w-4" />
                <span>{specialty.name} ({specialty.doctorCount})</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Doctors List */}
      {doctors.length === 0 ? (
        <div className="text-center py-8">
          <div className="text-gray-500 mb-2">No doctors found</div>
          <div className="text-sm text-gray-400">
            {selectedSpecialty === 'all' 
              ? 'No doctors are currently assigned to this hospital.'
              : 'No doctors found for the selected specialty at this hospital.'
            }
          </div>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-6">
          {doctors.map((doctor) => (
            <DoctorCard 
              key={`${doctor.id}-${doctor.assignment.specialtyId}`}
              doctor={doctor} 
              assignment={doctor.assignment}
              hospital={hospital}
            />
          ))}
        </div>
      )}
    </div>
  );
};

interface DoctorCardProps {
  doctor: Doctor & { assignment: HospitalDoctorAssignment };
  assignment: HospitalDoctorAssignment;
  hospital: any;
}

const DoctorCard: React.FC<DoctorCardProps> = ({ doctor, assignment, hospital }) => {
  return (
    <div className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
      <div className="flex items-start space-x-4">
        <div className="relative">
          <img
            src={doctor.image}
            alt={doctor.name}
            className="w-20 h-20 object-cover rounded-lg"
          />
          {doctor.verified && (
            <div className="absolute -top-1 -right-1 bg-green-500 text-white p-1 rounded-full">
              <CheckCircle className="h-3 w-3" />
            </div>
          )}
        </div>

        <div className="flex-1">
          <h3 className="text-lg font-semibold text-gray-900 mb-1">
            {doctor.name}
          </h3>
          <p className="text-blue-600 font-medium mb-2">{doctor.specialty}</p>

          <div className="flex items-center space-x-4 mb-3">
            <div className="flex items-center space-x-1">
              <Star className="h-4 w-4 text-yellow-400 fill-current" />
              <span className="font-medium text-sm">{doctor.rating}</span>
              <span className="text-gray-600 text-sm">({doctor.reviews})</span>
            </div>
            <div className="text-gray-600 text-sm">{doctor.experience} exp.</div>
          </div>

          {/* Chamber Location */}
          {assignment.chamberLocation && (
            <div className="flex items-center space-x-2 mb-3">
              <MapPin className="h-4 w-4 text-gray-500" />
              <span className="text-sm text-gray-600">{assignment.chamberLocation}</span>
            </div>
          )}

          {/* Schedule */}
          <div className="mb-4">
            <div className="text-sm font-medium text-gray-900 mb-2">Schedule at this hospital:</div>
            <div className="space-y-1">
              {assignment.schedule.slice(0, 3).map((schedule, idx) => (
                <div key={idx} className="flex items-center space-x-2 text-sm">
                  <Clock className="h-3 w-3 text-blue-600" />
                  <span className="font-medium text-gray-900">{schedule.day}:</span>
                  <span className="text-gray-600">{schedule.time}</span>
                </div>
              ))}
              {assignment.schedule.length > 3 && (
                <div className="text-xs text-gray-500">
                  +{assignment.schedule.length - 3} more days
                </div>
              )}
            </div>
          </div>

          {/* Appointment Process */}
          <div className="mb-4">
            <div className="text-sm font-medium text-gray-900 mb-1">How to book appointment:</div>
            <p className="text-xs text-gray-600 leading-relaxed">
              {assignment.appointmentProcess}
            </p>
          </div>

          {/* Contact Actions */}
          <div className="grid grid-cols-2 gap-3">
            <a
              href={`tel:${hospital.phone}`}
              className="flex items-center justify-center space-x-1 px-3 py-2 border border-blue-600 text-blue-600 rounded-lg hover:bg-blue-50 transition-colors text-sm"
            >
              <Phone className="h-3 w-3" />
              <span>Call Hospital</span>
            </a>
            <Link
              to={`/doctor/${doctor.id}`}
              className="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-center text-sm"
            >
              View Profile
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HospitalDoctorsList;