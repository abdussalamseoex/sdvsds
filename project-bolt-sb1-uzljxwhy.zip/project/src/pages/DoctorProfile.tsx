import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  Star, MapPin, Phone, Mail, Calendar, Clock, Award, 
  CheckCircle, GraduationCap, Briefcase, Users, Heart,
  ArrowLeft, MessageCircle, Video, DollarSign, Building2,
  Globe, ExternalLink
} from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { HospitalDoctorService } from '../services/hospitalDoctorService';

const DoctorProfile = () => {
  const { id } = useParams<{ id: string }>();

  if (!id) {
    return <div>Doctor ID not provided</div>;
  }

  // Get doctor data using the service
  const doctor = HospitalDoctorService.getDoctorById(id);
  
  if (!doctor) {
    return (
      <>
        <Header />
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Doctor Not Found</h1>
            <p className="text-gray-600 mb-6">The doctor you're looking for doesn't exist.</p>
            <Link to="/" className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors">
              Back to Home
            </Link>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  // Get hospitals where this doctor practices
  const hospitalAssignments = HospitalDoctorService.getHospitalsByDoctor(id);

  // Demo additional data (in a real app, this would come from the database)
  const doctorDetails = {
    about: `${doctor.name} is a renowned ${doctor.specialty.toLowerCase()} with over ${doctor.experience} of experience in treating complex medical conditions. Known for expertise in advanced medical procedures and patient-centered care.`,
    education: [
      {
        degree: 'MBBS',
        institution: 'Medical College',
        year: '1998'
      },
      {
        degree: 'Specialization',
        institution: 'National Institute',
        year: '2003'
      },
      {
        degree: 'Fellowship',
        institution: 'International Medical Center',
        year: '2005'
      }
    ],
    experience_details: [
      {
        position: 'Senior Consultant',
        hospital: 'Leading Medical Center',
        duration: '2015 - Present'
      },
      {
        position: 'Consultant',
        hospital: 'General Hospital',
        duration: '2010 - 2015'
      },
      {
        position: 'Assistant Consultant',
        hospital: 'Medical Institute',
        duration: '2005 - 2010'
      }
    ],
    specializations: [
      'Advanced Medical Procedures',
      'Patient Care',
      'Medical Consultation',
      'Treatment Planning',
      'Emergency Care',
      'Preventive Medicine'
    ],
    awards: [
      'Best Doctor Award 2020',
      'Excellence in Medical Service 2018',
      'Outstanding Contribution to Medicine 2016'
    ]
  };

  return (
    <>
      <Header />
      
      <div className="min-h-screen bg-gray-50">
        {/* Breadcrumb */}
        <div className="bg-white border-b">
          <div className="max-w-7xl mx-auto px-4 py-4">
            <div className="flex items-center space-x-2 text-sm">
              <Link to="/" className="text-blue-600 hover:text-blue-800">Home</Link>
              <span className="text-gray-400">/</span>
              <Link to="/" className="text-blue-600 hover:text-blue-800">Doctors</Link>
              <span className="text-gray-400">/</span>
              <span className="text-gray-600">{doctor.name}</span>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-8">
              {/* Doctor Header */}
              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex flex-col md:flex-row gap-6">
                  <div className="relative">
                    <img
                      src={doctor.image}
                      alt={doctor.name}
                      className="w-48 h-48 object-cover rounded-xl"
                    />
                    {doctor.verified && (
                      <div className="absolute top-2 right-2 bg-green-500 text-white p-1 rounded-full">
                        <CheckCircle className="h-4 w-4" />
                      </div>
                    )}
                  </div>

                  <div className="flex-1">
                    <h1 className="text-3xl font-bold text-gray-900 mb-2">
                      {doctor.name}
                    </h1>
                    <p className="text-xl text-blue-600 font-medium mb-4">
                      {doctor.specialty}
                    </p>

                    <div className="flex flex-wrap items-center gap-6 mb-4">
                      <div className="flex items-center space-x-1">
                        <Star className="h-5 w-5 text-yellow-400 fill-current" />
                        <span className="font-semibold text-lg">{doctor.rating}</span>
                        <span className="text-gray-600">({doctor.reviews} reviews)</span>
                      </div>
                      <div className="flex items-center space-x-1 text-gray-600">
                        <Briefcase className="h-5 w-5" />
                        <span>{doctor.experience} experience</span>
                      </div>
                      <div className="flex items-center space-x-1 text-gray-600">
                        <Users className="h-5 w-5" />
                        <span>1000+ patients treated</span>
                      </div>
                    </div>

                    <div className="bg-blue-50 p-4 rounded-lg">
                      <h3 className="font-semibold text-blue-900 mb-2">How to Contact & Book Appointment:</h3>
                      <p className="text-blue-800 text-sm">
                        This is a directory service. Please contact the doctor directly or through the hospitals listed below for appointment booking.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Chamber Information - Dynamic based on hospital assignments */}
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Chamber Information & Appointment Details</h2>
                {hospitalAssignments.length === 0 ? (
                  <div className="text-center py-8">
                    <div className="text-gray-500 mb-2">No hospital assignments found</div>
                    <div className="text-sm text-gray-400">
                      This doctor is not currently assigned to any hospitals in our directory.
                    </div>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {hospitalAssignments.map((hospitalData, index) => (
                      <div key={index} className="border border-gray-200 rounded-lg p-6">
                        <div className="flex items-start justify-between mb-4">
                          <div>
                            <h3 className="text-xl font-semibold text-gray-900 mb-2">{hospitalData.name}</h3>
                            <div className="flex items-start space-x-2 mb-2">
                              <MapPin className="h-4 w-4 text-gray-500 mt-1" />
                              <span className="text-gray-600">{hospitalData.address}</span>
                            </div>
                            <div className="flex items-center space-x-2 mb-2">
                              <Phone className="h-4 w-4 text-gray-500" />
                              <a href={`tel:${hospitalData.phone}`} className="text-blue-600 hover:text-blue-800">
                                {hospitalData.phone}
                              </a>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Globe className="h-4 w-4 text-gray-500" />
                              <a href={`https://${hospitalData.website}`} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-800 flex items-center space-x-1">
                                <span>{hospitalData.website}</span>
                                <ExternalLink className="h-3 w-3" />
                              </a>
                            </div>
                          </div>
                        </div>

                        <div className="grid md:grid-cols-2 gap-6">
                          <div>
                            <h4 className="font-semibold text-gray-900 mb-3">Schedule:</h4>
                            <div className="space-y-2">
                              {hospitalData.assignment.schedule.map((schedule, idx) => (
                                <div key={idx} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                                  <span className="font-medium text-gray-900">{schedule.day}</span>
                                  <span className="text-gray-600">{schedule.time}</span>
                                </div>
                              ))}
                            </div>
                            {hospitalData.assignment.chamberLocation && (
                              <div className="mt-3 p-2 bg-blue-50 rounded">
                                <div className="flex items-center space-x-2">
                                  <Building2 className="h-4 w-4 text-blue-600" />
                                  <span className="text-sm text-blue-800">{hospitalData.assignment.chamberLocation}</span>
                                </div>
                              </div>
                            )}
                          </div>

                          <div>
                            <h4 className="font-semibold text-gray-900 mb-3">How to Book Appointment:</h4>
                            <p className="text-gray-600 text-sm leading-relaxed mb-4">
                              {hospitalData.assignment.appointmentProcess}
                            </p>
                            <div className="space-y-2">
                              <a
                                href={`tel:${hospitalData.phone}`}
                                className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium flex items-center justify-center space-x-2"
                              >
                                <Phone className="h-4 w-4" />
                                <span>Call Hospital</span>
                              </a>
                              <Link
                                to={`/hospital/${hospitalData.id}`}
                                className="w-full border border-blue-600 text-blue-600 py-2 px-4 rounded-lg hover:bg-blue-50 transition-colors font-medium flex items-center justify-center space-x-2"
                              >
                                <Building2 className="h-4 w-4" />
                                <span>View Hospital</span>
                              </Link>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* About */}
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-4">About Dr. {doctor.name.split(' ').pop()}</h2>
                <p className="text-gray-600 leading-relaxed">
                  {doctorDetails.about}
                </p>
              </div>

              {/* Specializations */}
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Specializations</h2>
                <div className="grid md:grid-cols-2 gap-3">
                  {doctorDetails.specializations.map((specialization, index) => (
                    <div key={index} className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                      <Heart className="h-5 w-5 text-blue-600" />
                      <span className="text-gray-700">{specialization}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Education */}
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Education</h2>
                <div className="space-y-4">
                  {doctorDetails.education.map((edu, index) => (
                    <div key={index} className="flex items-start space-x-4 p-4 border border-gray-200 rounded-lg">
                      <GraduationCap className="h-6 w-6 text-blue-600 mt-1" />
                      <div>
                        <h3 className="font-semibold text-gray-900">{edu.degree}</h3>
                        <p className="text-gray-600">{edu.institution}</p>
                        <p className="text-sm text-gray-500">{edu.year}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Experience */}
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Professional Experience</h2>
                <div className="space-y-4">
                  {doctorDetails.experience_details.map((exp, index) => (
                    <div key={index} className="flex items-start space-x-4 p-4 border border-gray-200 rounded-lg">
                      <Briefcase className="h-6 w-6 text-green-600 mt-1" />
                      <div>
                        <h3 className="font-semibold text-gray-900">{exp.position}</h3>
                        <p className="text-gray-600">{exp.hospital}</p>
                        <p className="text-sm text-gray-500">{exp.duration}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Awards */}
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Awards & Recognition</h2>
                <div className="space-y-3">
                  {doctorDetails.awards.map((award, index) => (
                    <div key={index} className="flex items-center space-x-3 p-3 bg-yellow-50 rounded-lg">
                      <Award className="h-5 w-5 text-yellow-600" />
                      <span className="text-gray-700">{award}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Contact Information */}
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">Direct Contact</h3>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <Phone className="h-5 w-5 text-blue-600" />
                    <div>
                      <div className="font-medium text-gray-900">Phone</div>
                      <a href={`tel:${doctor.phone}`} className="text-blue-600 hover:text-blue-800">
                        {doctor.phone}
                      </a>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Mail className="h-5 w-5 text-red-600" />
                    <div>
                      <div className="font-medium text-gray-900">Email</div>
                      <a href={`mailto:${doctor.email}`} className="text-red-600 hover:text-red-800">
                        {doctor.email}
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              {/* Consultation Fees */}
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">Consultation Fees</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                    <span className="text-gray-700">New Patient</span>
                    <span className="font-semibold text-blue-600">৳{doctor.consultationFee.new_patient}</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                    <span className="text-gray-700">Follow-up</span>
                    <span className="font-semibold text-green-600">৳{doctor.consultationFee.follow_up}</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
                    <span className="text-gray-700">Online Consultation</span>
                    <span className="font-semibold text-purple-600">৳{doctor.consultationFee.online}</span>
                  </div>
                </div>
                <p className="text-xs text-gray-500 mt-3">
                  * Fees may vary. Please confirm with the doctor or hospital before appointment.
                </p>
              </div>

              {/* Directory Notice */}
              <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl p-6 text-white">
                <h3 className="text-lg font-bold mb-4">Directory Service Notice</h3>
                <p className="text-blue-100 mb-4 text-sm">
                  This is a healthcare directory. We provide contact information to help you connect with healthcare providers. Please contact them directly for appointments.
                </p>
                <div className="space-y-3">
                  <div className="text-sm">
                    <div className="font-medium">For Emergencies:</div>
                    <div className="text-blue-100">Call hospital emergency numbers directly</div>
                  </div>
                  <div className="text-sm">
                    <div className="font-medium">For Appointments:</div>
                    <div className="text-blue-100">Use contact information provided above</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
};

export default DoctorProfile;