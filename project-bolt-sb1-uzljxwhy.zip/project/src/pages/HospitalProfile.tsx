import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  Star, MapPin, Phone, Mail, Globe, Clock, Bed, Users, 
  Award, CheckCircle, ArrowLeft, Shield, Car, ExternalLink
} from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import HospitalDoctorsList from '../components/HospitalDoctorsList';
import { HospitalDoctorService } from '../services/hospitalDoctorService';

const HospitalProfile = () => {
  const { id } = useParams<{ id: string }>();

  if (!id) {
    return <div>Hospital ID not provided</div>;
  }

  // Get hospital data using the service
  const hospital = HospitalDoctorService.getHospitalById(id);

  if (!hospital) {
    return (
      <>
        <Header />
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Hospital Not Found</h1>
            <p className="text-gray-600 mb-6">The hospital you're looking for doesn't exist.</p>
            <Link to="/" className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors">
              Back to Home
            </Link>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Header />
      
      <div className="min-h-screen bg-gray-50">
        {/* Breadcrumb */}
        <div className="bg-white border-b">
          <div className="max-w-7xl mx-auto px-4 py-4">
            <div className="flex items-center space-x-2 text-sm">
              <Link to="/" className="text-blue-600 hover:text-blue-800">Home</Link>
              <span className="text-gray-400">/</span>
              <Link to="/" className="text-blue-600 hover:text-blue-800">Hospitals</Link>
              <span className="text-gray-400">/</span>
              <span className="text-gray-600">{hospital.name}</span>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-8">
              {/* Hospital Header */}
              <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                <div className="relative h-64">
                  <img
                    src={hospital.image}
                    alt={hospital.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-4 left-4 flex space-x-2">
                    {hospital.accredited && (
                      <div className="bg-green-500 text-white px-3 py-1 rounded-full flex items-center space-x-1 text-sm">
                        <CheckCircle className="h-4 w-4" />
                        <span>Accredited</span>
                      </div>
                    )}
                    {hospital.emergency && (
                      <div className="bg-red-500 text-white px-3 py-1 rounded-full flex items-center space-x-1 text-sm">
                        <Clock className="h-4 w-4" />
                        <span>24/7 Emergency</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="p-6">
                  <h1 className="text-3xl font-bold text-gray-900 mb-4">
                    {hospital.name}
                  </h1>

                  <div className="flex items-center space-x-6 mb-4">
                    <div className="flex items-center space-x-1">
                      <Star className="h-5 w-5 text-yellow-400 fill-current" />
                      <span className="font-semibold text-lg">{hospital.rating}</span>
                      <span className="text-gray-600">({hospital.reviews} reviews)</span>
                    </div>
                    <div className="flex items-center space-x-1 text-gray-600">
                      <MapPin className="h-5 w-5" />
                      <span>{hospital.location}</span>
                    </div>
                  </div>

                  <p className="text-gray-600 leading-relaxed mb-6">
                    {hospital.description}
                  </p>

                  <div className="bg-blue-50 p-4 rounded-lg mb-6">
                    <h3 className="font-semibold text-blue-900 mb-2">Directory Service Notice:</h3>
                    <p className="text-blue-800 text-sm">
                      This is a healthcare directory. Please contact the hospital directly using the information provided below for appointments and services.
                    </p>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <Bed className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-gray-900">{hospital.beds}</div>
                      <div className="text-sm text-gray-600">Beds</div>
                    </div>
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <Users className="h-8 w-8 text-green-600 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-gray-900">
                        {HospitalDoctorService.getDoctorsByHospital(hospital.id).length}
                      </div>
                      <div className="text-sm text-gray-600">Doctors</div>
                    </div>
                    <div className="text-center p-4 bg-purple-50 rounded-lg">
                      <Award className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-gray-900">{hospital.established}</div>
                      <div className="text-sm text-gray-600">Established</div>
                    </div>
                    <div className="text-center p-4 bg-orange-50 rounded-lg">
                      <Shield className="h-8 w-8 text-orange-600 mx-auto mb-2" />
                      <div className="text-2xl font-bold text-gray-900">A+</div>
                      <div className="text-sm text-gray-600">Rating</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Dynamic Doctors List */}
              <HospitalDoctorsList hospitalId={hospital.id} />

              {/* Appointment Information */}
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">How to Book Appointments</h2>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-3">General Appointments:</h3>
                    <p className="text-gray-600 mb-4">
                      Appointments can be made by calling the hospital reception, visiting in person, or through the hospital website. Emergency cases are accepted 24/7.
                    </p>
                    
                    <div className="space-y-2 mb-4">
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span className="text-sm text-gray-700">Online booking: Available through hospital website</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span className="text-sm text-gray-700">Advance booking: 1-2 weeks recommended for specialist consultations</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-semibold text-gray-900 mb-3">Emergency Cases:</h3>
                    <p className="text-gray-600 mb-4">
                      Walk-in emergency cases accepted 24/7. Call emergency hotline for ambulance service.
                    </p>
                    
                    <div className="bg-red-50 p-4 rounded-lg">
                      <div className="flex items-center space-x-2 mb-2">
                        <Car className="h-5 w-5 text-red-600" />
                        <span className="font-semibold text-red-900">Emergency Hotline</span>
                      </div>
                      <a href={`tel:${hospital.emergency_phone}`} className="text-red-600 font-bold text-lg">
                        {hospital.emergency_phone}
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              {/* Operating Hours */}
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Operating Hours</h2>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="p-4 border border-gray-200 rounded-lg">
                      <h3 className="font-semibold text-gray-900 mb-2">OPD (Outpatient)</h3>
                      <p className="text-gray-600">{hospital.operating_hours.opd}</p>
                    </div>
                    <div className="p-4 border border-red-200 bg-red-50 rounded-lg">
                      <h3 className="font-semibold text-red-900 mb-2">Emergency</h3>
                      <p className="text-red-700 font-medium">{hospital.operating_hours.emergency}</p>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="p-4 border border-gray-200 rounded-lg">
                      <h3 className="font-semibold text-gray-900 mb-2">Pharmacy</h3>
                      <p className="text-gray-600">{hospital.operating_hours.pharmacy}</p>
                    </div>
                    <div className="p-4 border border-gray-200 rounded-lg">
                      <h3 className="font-semibold text-gray-900 mb-2">Laboratory</h3>
                      <p className="text-gray-600">{hospital.operating_hours.lab}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Facilities & Services */}
              <div className="grid md:grid-cols-2 gap-8">
                <div className="bg-white rounded-xl shadow-lg p-6">
                  <h2 className="text-2xl font-bold text-gray-900 mb-6">Facilities</h2>
                  <ul className="space-y-3">
                    {hospital.facilities.map((facility, index) => (
                      <li key={index} className="flex items-center space-x-3">
                        <CheckCircle className="h-5 w-5 text-green-500" />
                        <span className="text-gray-700">{facility}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-white rounded-xl shadow-lg p-6">
                  <h2 className="text-2xl font-bold text-gray-900 mb-6">Services</h2>
                  <ul className="space-y-3">
                    {hospital.services.map((service, index) => (
                      <li key={index} className="flex items-center space-x-3">
                        <CheckCircle className="h-5 w-5 text-blue-500" />
                        <span className="text-gray-700">{service}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Gallery */}
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Hospital Gallery</h2>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {hospital.gallery.map((image, index) => (
                    <img
                      key={index}
                      src={image}
                      alt={`Hospital view ${index + 1}`}
                      className="w-full h-32 object-cover rounded-lg hover:scale-105 transition-transform cursor-pointer"
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Contact Information */}
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">Contact Information</h3>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <MapPin className="h-5 w-5 text-blue-600 mt-1" />
                    <div>
                      <div className="font-medium text-gray-900">Address</div>
                      <div className="text-gray-600">{hospital.address}</div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Phone className="h-5 w-5 text-green-600" />
                    <div>
                      <div className="font-medium text-gray-900">General</div>
                      <a href={`tel:${hospital.phone}`} className="text-green-600 hover:text-green-800">
                        {hospital.phone}
                      </a>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Phone className="h-5 w-5 text-red-600" />
                    <div>
                      <div className="font-medium text-gray-900">Emergency</div>
                      <a href={`tel:${hospital.emergency_phone}`} className="text-red-600 hover:text-red-800">
                        {hospital.emergency_phone}
                      </a>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Mail className="h-5 w-5 text-blue-600" />
                    <div>
                      <div className="font-medium text-gray-900">Email</div>
                      <a href={`mailto:${hospital.email}`} className="text-blue-600 hover:text-blue-800">
                        {hospital.email}
                      </a>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Globe className="h-5 w-5 text-purple-600" />
                    <div>
                      <div className="font-medium text-gray-900">Website</div>
                      <a href={`https://${hospital.website}`} target="_blank" rel="noopener noreferrer" className="text-purple-600 hover:text-purple-800 flex items-center space-x-1">
                        <span>{hospital.website}</span>
                        <ExternalLink className="h-3 w-3" />
                      </a>
                    </div>
                  </div>
                </div>

                <div className="mt-6 space-y-3">
                  <a
                    href={`tel:${hospital.phone}`}
                    className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium flex items-center justify-center space-x-2"
                  >
                    <Phone className="h-4 w-4" />
                    <span>Call Hospital</span>
                  </a>
                  <a
                    href={`https://${hospital.website}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full border border-blue-600 text-blue-600 py-3 rounded-lg hover:bg-blue-50 transition-colors font-medium flex items-center justify-center space-x-2"
                  >
                    <Globe className="h-4 w-4" />
                    <span>Visit Website</span>
                  </a>
                </div>
              </div>

              {/* Emergency Services */}
              <div className="bg-red-50 border border-red-200 rounded-xl p-6">
                <div className="flex items-center space-x-2 mb-3">
                  <Car className="h-6 w-6 text-red-600" />
                  <h3 className="text-lg font-bold text-red-900">Emergency Services</h3>
                </div>
                <p className="text-red-800 mb-4">24/7 emergency care available with ambulance service</p>
                <a
                  href={`tel:${hospital.emergency_phone}`}
                  className="w-full bg-red-600 text-white py-3 rounded-lg hover:bg-red-700 transition-colors font-medium flex items-center justify-center space-x-2"
                >
                  <Phone className="h-4 w-4" />
                  <span>Emergency Contact</span>
                </a>
              </div>

              {/* Directory Notice */}
              <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl p-6 text-white">
                <h3 className="text-lg font-bold mb-4">Healthcare Directory</h3>
                <p className="text-blue-100 mb-4 text-sm">
                  We provide comprehensive contact information to help you connect with healthcare facilities. Please contact them directly for services and appointments.
                </p>
                <div className="space-y-2 text-sm">
                  <div>
                    <div className="font-medium">For Appointments:</div>
                    <div className="text-blue-100">Call or visit hospital directly</div>
                  </div>
                  <div>
                    <div className="font-medium">For Emergencies:</div>
                    <div className="text-blue-100">Use emergency contact numbers</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
};

export default HospitalProfile;