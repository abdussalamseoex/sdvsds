import React from 'react';
import Header from '../components/Header';
import Hero from '../components/Hero';
import Specialties from '../components/Specialties';
import FeaturedDoctors from '../components/FeaturedDoctors';
import FeaturedHospitals from '../components/FeaturedHospitals';
import Stats from '../components/Stats';
import Testimonials from '../components/Testimonials';
import Footer from '../components/Footer';

const HomePage = () => {
  return (
    <>
      <Header />
      <Hero />
      <Stats />
      <Specialties />
      <FeaturedDoctors />
      <FeaturedHospitals />
      <Testimonials />
      <Footer />
    </>
  );
};

export default HomePage;